
# 📚 References

1. Wilson, P. W. F., et al. (1998). Prediction of coronary heart disease...
2. Weng, S. F., et al. (2017). Can machine-learning improve cardiovascular...
3. SHAP: https://shap.readthedocs.io/
4. UCI Heart Dataset: https://archive.ics.uci.edu/ml/datasets/heart+Disease
5. Framingham Dataset (Kaggle): https://www.kaggle.com/datasets/amanajmera1
