
# 🫀 Cardiovascular Risk Prediction Using Python

This project uses clinical data and modern machine learning techniques to predict the risk of cardiovascular disease.
It includes full data pipelines, modeling, interpretability tools, and an interactive web app.

## 📁 Repository Structure

- `data/` - Raw and processed datasets
- `notebooks/` - Jupyter notebooks for each stage
- `models/` - Saved trained models
- `app/` - Streamlit code for interactive dashboard
- `utils/` - Helper scripts
- `requirements.txt` - Python dependencies
- `references.md` - Academic and technical references

## ⚙️ How to Run

```bash
git clone https://github.com/yourusername/CardioRiskPrediction.git
cd CardioRiskPrediction
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

## 📜 License

MIT License © 2025 Your Name
